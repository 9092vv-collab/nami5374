/* eslint-disable */
// Screen tag S1701 is TEMPORARY (src/debug-tags.js)
import Screen from '../src/m/1701';
import { withScreenTag } from '../src/debug-tags';
export * from '../src/m/1701';
export default withScreenTag(Screen, '1701');
