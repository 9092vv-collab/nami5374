/* eslint-disable */
// Screen tag S1710 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1710';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1710';
export default withScreenTag(Screen, '1710');
