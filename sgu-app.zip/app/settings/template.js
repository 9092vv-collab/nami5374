/* eslint-disable */
// Screen tag S1714 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1714';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1714';
export default withScreenTag(Screen, '1714');
