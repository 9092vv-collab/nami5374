/* eslint-disable */
// Screen tag S1705 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1705';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1705';
export default withScreenTag(Screen, '1705');
