/* eslint-disable */
// Screen tag S1711 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1711';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1711';
export default withScreenTag(Screen, '1711');
