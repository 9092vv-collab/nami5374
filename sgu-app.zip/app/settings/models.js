/* eslint-disable */
// Screen tag S1708 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1708';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1708';
export default withScreenTag(Screen, '1708');
