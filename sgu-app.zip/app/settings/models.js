export * from '../../src/m/1708';
export { default } from '../../src/m/1708';
