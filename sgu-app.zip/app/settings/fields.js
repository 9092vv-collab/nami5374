/* eslint-disable */
// Screen tag S1704 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1704';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1704';
export default withScreenTag(Screen, '1704');
