export * from '../../src/m/1704';
export { default } from '../../src/m/1704';
