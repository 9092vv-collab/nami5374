/* eslint-disable */
// Screen tag S1709 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1709';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1709';
export default withScreenTag(Screen, '1709');
