/* eslint-disable */
// Screen tag S1703 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1703';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1703';
export default withScreenTag(Screen, '1703');
