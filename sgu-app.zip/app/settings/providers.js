/* eslint-disable */
// Screen tag S1713 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1713';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1713';
export default withScreenTag(Screen, '1713');
