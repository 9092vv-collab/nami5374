/* eslint-disable */
// Screen tag S1706 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1706';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1706';
export default withScreenTag(Screen, '1706');
