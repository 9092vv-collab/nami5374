export * from '../../src/m/1706';
export { default } from '../../src/m/1706';
