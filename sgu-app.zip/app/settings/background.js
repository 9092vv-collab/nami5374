export * from '../../src/m/1702';
export { default } from '../../src/m/1702';
