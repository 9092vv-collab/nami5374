/* eslint-disable */
// Screen tag S1702 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1702';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1702';
export default withScreenTag(Screen, '1702');
