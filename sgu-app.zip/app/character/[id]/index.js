/* eslint-disable */
// Screen tag S1655 is TEMPORARY (src/debug-tags.js)
import Screen from '../../../src/m/1655';
import { withScreenTag } from '../../../src/debug-tags';
export * from '../../../src/m/1655';
export default withScreenTag(Screen, '1655');
