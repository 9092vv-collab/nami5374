/* eslint-disable */
// Screen tag S1691 is TEMPORARY (src/debug-tags.js)
import Screen from '../../../src/m/1691';
import { withScreenTag } from '../../../src/debug-tags';
export * from '../../../src/m/1691';
export default withScreenTag(Screen, '1691');
