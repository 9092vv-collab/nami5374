/* eslint-disable */
// Screen tag S1694 is TEMPORARY (src/debug-tags.js)
import Screen from '../../../src/m/1694';
import { withScreenTag } from '../../../src/debug-tags';
export * from '../../../src/m/1694';
export default withScreenTag(Screen, '1694');
