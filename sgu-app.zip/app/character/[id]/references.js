/* eslint-disable */
// Screen tag S1695 is TEMPORARY (src/debug-tags.js)
import Screen from '../../../src/m/1695';
import { withScreenTag } from '../../../src/debug-tags';
export * from '../../../src/m/1695';
export default withScreenTag(Screen, '1695');
