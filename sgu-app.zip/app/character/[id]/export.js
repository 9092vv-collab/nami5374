/* eslint-disable */
// Screen tag S1651 is TEMPORARY (src/debug-tags.js)
import Screen from '../../../src/m/1651';
import { withScreenTag } from '../../../src/debug-tags';
export * from '../../../src/m/1651';
export default withScreenTag(Screen, '1651');
