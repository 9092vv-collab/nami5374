import '../global.css';
import '../src/boot';
export * from '../src/m/1082';
export { default } from '../src/m/1082';
