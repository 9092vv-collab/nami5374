/* eslint-disable */
// Screen tag S1064 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1064';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1064';
export default withScreenTag(Screen, '1064');
