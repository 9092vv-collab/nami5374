/* eslint-disable */
// Screen tag S1073 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1073';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1073';
export default withScreenTag(Screen, '1073');
