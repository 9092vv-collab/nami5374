/* eslint-disable */
// Screen tag S849 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/849';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/849';
export default withScreenTag(Screen, '849');
