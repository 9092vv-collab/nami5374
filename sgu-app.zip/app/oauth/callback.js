/* eslint-disable */
// Screen tag S1699 is TEMPORARY (src/debug-tags.js)
import Screen from '../../src/m/1699';
import { withScreenTag } from '../../src/debug-tags';
export * from '../../src/m/1699';
export default withScreenTag(Screen, '1699');
