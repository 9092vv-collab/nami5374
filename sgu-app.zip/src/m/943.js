/* eslint-disable */
// auto-converted from SGU web bundle module 943
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),Object.defineProperty(e,"ProviderError",{enumerable:!0,get:function(){return t}}),e.textOf=function(t){return"string"==typeof t?t:t.filter(t=>"text"===t.type).map(t=>t.text).join("\n")};class t extends Error{constructor(t,n={}){super(t),this.name="ProviderError",this.status=n.status,this.retryable=n.retryable??!1,this.body=n.body,this.kind=n.kind}}})(global,__r,__i,__a,module,exports,[]);
