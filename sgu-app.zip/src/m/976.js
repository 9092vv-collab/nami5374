/* eslint-disable */
// Notifications + battery-optimization request (Android). Replaces web stubs.
const Notifications = require('expo-notifications');
const IntentLauncher = require('expo-intent-launcher');
const Constants = require('expo-constants').default;
let configured = false;
Object.defineProperty(exports, '__esModule', { value: true });
exports.configureNotifications = function () {
  if (configured) return; configured = true;
  Notifications.setNotificationHandler({ handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false }) });
  Notifications.setNotificationChannelAsync('sgu-jobs', { name: 'SGU 작업 알림', importance: Notifications.AndroidImportance.DEFAULT }).catch(() => {});
};
exports.requestNotificationPermission = async function () {
  try { const cur = await Notifications.getPermissionsAsync(); if (cur.granted) return true; const r = await Notifications.requestPermissionsAsync(); return !!r.granted; } catch { return false; }
};
exports.notify = async function (title, body, opts = {}) {
  try { exports.configureNotifications(); await Notifications.scheduleNotificationAsync({ content: { title, body, data: opts.data || {} }, trigger: { channelId: 'sgu-jobs' } }); } catch {}
};
exports.requestIgnoreBatteryOptimizations = async function () {
  try {
    const pkg = (Constants.expoConfig && Constants.expoConfig.android && Constants.expoConfig.android.package) || 'space.sgu.fold';
    await IntentLauncher.startActivityAsync('android.settings.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS', { data: 'package:' + pkg });
    return true;
  } catch {
    try { await IntentLauncher.startActivityAsync('android.settings.IGNORE_BATTERY_OPTIMIZATION_SETTINGS'); return true; } catch { return false; }
  }
};
