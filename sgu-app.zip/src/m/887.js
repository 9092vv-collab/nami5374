/* eslint-disable */
// API keys in Android secure storage (expo-secure-store). Replaces the web localStorage version.
const SecureStore = require('expo-secure-store');
const PREFIX = 'sgu_key_';
const k = (n) => (PREFIX + n).replace(/[^A-Za-z0-9._-]/g, '_');
Object.defineProperty(exports, '__esModule', { value: true });
async function getKeyValue(n) { try { return await SecureStore.getItemAsync(k(n)); } catch { return null; } }
exports.getKeyValue = getKeyValue;
exports.setKeyValue = async function (n, v) { await SecureStore.setItemAsync(k(n), String(v)); };
exports.deleteKeyValue = async function (n) { try { await SecureStore.deleteItemAsync(k(n)); } catch {} };
exports.maskKey = function (e) { return e ? (e.length <= 8 ? '•'.repeat(e.length) : `${e.slice(0, 4)}…${e.slice(-4)}`) : ''; };
