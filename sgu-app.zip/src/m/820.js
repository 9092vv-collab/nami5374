/* eslint-disable */
// Shared Pressable. The web bundle turned className into a react-native-web `$$css` style
// object, which does nothing on Android (buttons lost bg/flex-row). Here className goes
// straight to RN Pressable, which NativeWind styles. Shows a debug tag while enabled.
Object.defineProperty(exports, '__esModule', { value: true });
const { Pressable } = require('react-native');
const { tagPressable } = require('../debug-tags');
exports.Pressable = tagPressable(Pressable, 'Pressable');
