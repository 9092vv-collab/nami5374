/* eslint-disable */
// Shared Pressable. The web bundle turned className into a react-native-web `$$css` style
// object, which does nothing on Android (buttons lost bg/flex-row). Here className goes
// straight to RN Pressable, which NativeWind styles; long-press is kept as-is.
Object.defineProperty(exports, '__esModule', { value: true });
const React = require('react');
const { Pressable: RNPressable } = require('react-native');
const Pressable = React.forwardRef(function Pressable(props, ref) {
  return React.createElement(RNPressable, { ref, ...props });
});
Pressable.displayName = 'Pressable';
exports.Pressable = Pressable;
