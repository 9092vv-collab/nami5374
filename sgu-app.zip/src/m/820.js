/* eslint-disable */
// Shared Pressable. The web bundle turned className into a react-native-web `$$css` style
// object, which does nothing on Android (buttons lost bg/flex-row). Here className goes
// straight to RN Pressable, which NativeWind styles.
Object.defineProperty(exports, '__esModule', { value: true });
exports.Pressable = require('react-native').Pressable;
