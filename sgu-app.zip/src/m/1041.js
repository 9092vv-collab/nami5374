/* eslint-disable */
// auto-converted from SGU web bundle module 1041
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,_m,e,d){"use strict";function s(s){const o=s.processors.sub;return"jev"===o.strategy?!(!o.jevProviderId&&!s.providers.some(s=>"jev"===s.format)):!!o.modelId&&s.models.some(s=>s.id===o.modelId)}Object.defineProperty(e,'__esModule',{value:!0}),e.subAssigned=s,e.isSubOff=function(o){return!!o.processors.sub.disabled||!s(o)}})(global,__r,__i,__a,module,exports,[]);
