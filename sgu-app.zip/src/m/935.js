/* eslint-disable */
// auto-converted from SGU web bundle module 935
function __r(id){switch(id){case 936: return require('./936');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,_m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.jevSystemOne=async function(s,o,n,l,u={}){const y=(0,t.joinUrl)(s.baseUrl,"systemone"),m=await(0,t.httpRequest)({url:y,headers:(0,t.authHeaders)(s),body:{state:n,model:o,questions:l,...s.extraBody},signal:u.signal,timeoutMs:u.timeoutMs??6e4,retries:u.retries??1});return await m.json()},e.jevListModels=async function(s,o=2e4){const n=(0,t.joinUrl)(s.baseUrl,"models"),l=await(0,t.httpRequest)({method:"GET",url:n,headers:(0,t.authHeaders)(s),timeoutMs:o}),u=await l.json(),y=(Array.isArray(u)?u:Array.isArray(u?.data)?u.data:Array.isArray(u?.models)?u.models:[]).map(t=>"string"==typeof t?t:t.id??t.name??"").filter(Boolean);return y.length?y.sort():["jev-latest"]};var t=r(d[0])})(global,__r,__i,__a,module,exports,[936]);
