/* eslint-disable */
// auto-converted from SGU web bundle module 830
function __r(id){switch(id){case 831: return require('./831');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.useColorScheme=function(){return(0,o.useThemeContext)().colorScheme};var o=r(d[0])})(global,__r,__i,__a,module,exports,[831]);
