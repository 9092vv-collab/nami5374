/* eslint-disable */
// auto-converted from SGU web bundle module 836
function __r(id){switch(id){case 634: return require('../lib/634');case 837: return require('../lib/837');case 839: return require('../lib/839');case 1761: return require('../lib/1761');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.HapticTab=function(o){const c=(0,n.c)(5);let u,l;c[0]!==o?(u=n=>{o.onPressIn?.(n)},c[0]=o,c[1]=u):u=c[1];c[2]!==o||c[3]!==u?(l=(0,t.jsx)(s.PlatformPressable,{...o,onPressIn:u}),c[2]=o,c[3]=u,c[4]=l):l=c[4];return l};var n=r(d[0]),s=r(d[1]);r(d[2]);var t=r(d[3])})(global,__r,__i,__a,module,exports,[1761, 837, 839, 634]);
