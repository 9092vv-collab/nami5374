/* eslint-disable */
// auto-converted from SGU web bundle module 1697
function __r(id){switch(id){case 174: return require('../lib/174');case 634: return require('../lib/634');case 821: return require('./821');case 1761: return require('../lib/1761');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),_e.ThemedView=function(e){const c=(0,t.c)(8);let l,o,_,f;c[0]!==e?(({className:l,...o}=e),c[0]=e,c[1]=l,c[2]=o):(l=c[1],o=c[2]);c[3]!==l?(_=(0,u.cn)("bg-background",l),c[3]=l,c[4]=_):_=c[4];c[5]!==o||c[6]!==_?(f=(0,n.jsx)(s.default,{className:_,...o}),c[5]=o,c[6]=_,c[7]=f):f=c[7];return f};var e,t=r(d[0]),c=r(d[1]),s=(e=c)&&e.__esModule?e:{default:e},u=r(d[2]),n=r(d[3])})(global,__r,__i,__a,module,exports,[1761, 174, 821, 634]);
