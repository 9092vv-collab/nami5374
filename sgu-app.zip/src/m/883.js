/* eslint-disable */
// auto-converted from SGU web bundle module 883
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,_m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.effectiveVision=function(t){return t.visionSet?t.vision:t.vision||o(t.modelId)},e.guessVision=o;const t=/gpt-4o|gpt-4\.1|gpt-4\.5|gpt-4-turbo|gpt-4-vision|gpt-5|chatgpt-4o|\bo[134](-|$)|claude|gemini|gemma-3|pixtral|llava|vision|\bvl\b|-vl|qwen.*vl|qwen3-(omni|vl)|internvl|minicpm-v|grok-(2-vision|4|vision)|llama-?(3\.2-(11|90)b|4)|mistral-(medium|small)-(3|latest)|kimi-(k2\.5|vl)|glm-4\.?\d*v|doubao.*vision|step-1v/i,n=/embed|whisper|tts|dall-e|moderation|rerank|gpt-3\.5|instruct$|-coder-(?!.*vl)|codestral|deepseek-(chat|reasoner|r1|v3)(?!.*vl)/i;function o(o){return t.test(o)&&!n.test(o)}})(global,__r,__i,__a,module,exports,[]);
