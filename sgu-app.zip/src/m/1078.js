/* eslint-disable */
// auto-converted from SGU web bundle module 1078
function __r(id){switch(id){case 1079: return require('../lib/1079');case 1080: return require('../lib/1080');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),Object.defineProperty(e,"useIncomingShare",{enumerable:!0,get:function(){return t.useIncomingShare}});var t=r(d[0]),n=r(d[1]);Object.keys(n).forEach(function(t){'default'===t||Object.prototype.hasOwnProperty.call(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:function(){return n[t]}})})})(global,__r,__i,__a,module,exports,[1079, 1080]);
