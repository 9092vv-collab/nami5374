/* eslint-disable */
// auto-converted from SGU web bundle module 961
function __r(id){switch(id){case 891: return require('./891');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.activePreset=o,e.presetFor=s,e.resolveBlocks=function(o,n){return s(o,n)?.blocks??(0,t.defaultPromptBlocks)()};var t=r(d[0]);function o(o){return o.promptPresets.find(t=>t.id===o.activePromptPresetId)??o.promptPresets[0]??{id:"preset_default",name:"\uae30\ubcf8",blocks:(0,t.defaultPromptBlocks)(),createdAt:0}}function s(t,s){return t.promptPresets.find(t=>t.id===s.promptPresetId)??o(t)}})(global,__r,__i,__a,module,exports,[891]);
