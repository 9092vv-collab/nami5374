/* eslint-disable */
// auto-converted from SGU web bundle module 912
function __r(id){switch(id){case 882: return require('./882');case 895: return require('./895');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.fieldDescription=function(s,c){const o=(c??n.useSettings.getState().settings.fieldDescriptions)?.[s];return o?.trim()?o:t.FIELD_MAP[s]?.aiDescription??""};var t=r(d[0]),n=r(d[1])})(global,__r,__i,__a,module,exports,[895, 882]);
