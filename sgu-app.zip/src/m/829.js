/* eslint-disable */
// auto-converted from SGU web bundle module 829
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){m.exports={themeColors:{primary:{light:'#D97757',dark:'#D97757'},background:{light:'#F5F4ED',dark:'#1F1E1D'},surface:{light:'#FFFFFF',dark:'#262624'},foreground:{light:'#141413',dark:'#F5F4EE'},muted:{light:'#73726C',dark:'#A6A39A'},border:{light:'#E5E3DA',dark:'#3A3936'},success:{light:'#3F8F5A',dark:'#6BC28A'},warning:{light:'#B7791F',dark:'#E0B04A'},error:{light:'#C0392B',dark:'#F08A7E'}}}})(global,__r,__i,__a,module,exports,[]);
