/* eslint-disable */
// auto-converted from SGU web bundle module 886
function __r(id){switch(id){case 835: return require('./835');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,_d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.createDesktopStore=function(){const s=t.desktop,n=new Map,c=t=>n.set(t,(n.get(t)??0)+1);return{async readText(t){const n=await s.fsRead(t);return n?(new TextDecoder).decode(n):null},async writeText(t,n){await s.fsWrite(t,(new TextEncoder).encode(n))},readBytes:t=>s.fsRead(t),async writeBytes(t,n){await s.fsWrite(t,n),c(t)},exists:t=>s.fsExists(t),async remove(t){await s.fsRemove(t),c(t)},list:t=>s.fsList(t),async ensureDir(){},async importFromUri(t,n){const o=await fetch(t);await s.fsWrite(n,new Uint8Array(await o.arrayBuffer())),c(n)},async resolveUri(t){const c=n.get(t);return s.fsUrl(t)+(c?`?v=${c}`:"")},nativeFileUri:()=>null,size:t=>s.fsSize(t)}};var t=r(_d[0])})(global,__r,__i,__a,module,exports,[835]);
