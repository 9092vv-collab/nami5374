/* eslint-disable */
// auto-converted from SGU web bundle module 819
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.showToast=function(n,u=3500){t.forEach(t=>t(n)),o&&clearTimeout(o);o=setTimeout(()=>t.forEach(t=>t(null)),u)},e.subscribeToast=function(o){return t.add(o),()=>{t.delete(o)}};const t=new Set;let o=null})(global,__r,__i,__a,module,exports,[]);
