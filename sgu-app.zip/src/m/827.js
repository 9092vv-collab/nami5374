/* eslint-disable */
// auto-converted from SGU web bundle module 827
function __r(id){switch(id){case 828: return require('./828');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),Object.defineProperty(e,"Colors",{enumerable:!0,get:function(){return t.Colors}}),Object.defineProperty(e,"Fonts",{enumerable:!0,get:function(){return t.Fonts}}),Object.defineProperty(e,"SchemeColors",{enumerable:!0,get:function(){return t.SchemeColors}}),Object.defineProperty(e,"ThemeColors",{enumerable:!0,get:function(){return t.ThemeColors}});var t=r(d[0])})(global,__r,__i,__a,module,exports,[828]);
