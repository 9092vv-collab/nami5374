/* eslint-disable */
// SGU native document store (expo-file-system, Android). Replaces the web/IndexedDB store.
const { File, Directory, Paths } = require('expo-file-system');
const desktop = require('./835');
let root = null;
function base() {
  if (!root) { root = new Directory(Paths.document, 'sgu'); if (!root.exists) root.create({ intermediates: true, idempotent: true }); }
  return root;
}
const parts = (p) => String(p || '').split('/').filter(Boolean);
const fileOf = (p) => new File(base(), ...parts(p));
const dirOf = (p) => (parts(p).length ? new Directory(base(), ...parts(p)) : base());
function ensureParent(p) {
  const ps = parts(p); ps.pop();
  if (ps.length) { const d = new Directory(base(), ...ps); if (!d.exists) d.create({ intermediates: true, idempotent: true }); }
}
function isFile(p) { try { const f = fileOf(p); return f.exists ? f : null; } catch { return null; } }
function createNativeStore() {
  return {
    async readText(p) { const f = isFile(p); return f ? await f.text() : null; },
    async writeText(p, text) { ensureParent(p); const f = fileOf(p); if (!f.exists) f.create(); f.write(String(text)); },
    async readBytes(p) { const f = isFile(p); return f ? await f.bytes() : null; },
    async writeBytes(p, bytes) { ensureParent(p); const f = fileOf(p); if (!f.exists) f.create(); f.write(bytes); },
    async exists(p) { if (isFile(p)) return true; try { return dirOf(p).exists; } catch { return false; } },
    async remove(p) {
      const f = isFile(p); if (f) { f.delete(); return; }
      try { const d = dirOf(p); if (d.exists && parts(p).length) d.delete(); } catch {}
    },
    async list(p) { try { const d = dirOf(p); return d.exists ? d.list().map((x) => x.name) : []; } catch { return []; } },
    async ensureDir(p) { const d = dirOf(p); if (!d.exists) d.create({ intermediates: true, idempotent: true }); },
    async importFromUri(uri, p) {
      ensureParent(p); const dst = fileOf(p); if (dst.exists) dst.delete();
      const src = new File(uri);
      if (src.exists) { src.copy(dst); return; }
      const res = await fetch(uri); const buf = new Uint8Array(await res.arrayBuffer()); dst.create(); dst.write(buf);
    },
    async resolveUri(p) { const f = isFile(p); return f ? f.uri : ''; },
    nativeFileUri(p) { const f = isFile(p); return f ? f.uri : null; },
    async size(p) { const f = isFile(p); return f ? f.size : null; },
  };
}
Object.defineProperty(exports, '__esModule', { value: true });
exports.createDocumentStore = function () { return createNativeStore(); };
void desktop;
