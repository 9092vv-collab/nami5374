/* eslint-disable */
// auto-converted from SGU web bundle module 1698
function __r(id){switch(id){case 634: return require('../lib/634');case 800: return require('../lib/800');case 1761: return require('../lib/1761');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),_e.IconSymbol=function(e){const l=(0,o.c)(5),{name:s,size:h,color:u,style:f}=e,v=void 0===h?24:h,_=c[s];let p;l[0]!==u||l[1]!==v||l[2]!==f||l[3]!==_?(p=(0,n.jsx)(t.default,{color:u,size:v,name:_,style:f}),l[0]=u,l[1]=v,l[2]=f,l[3]=_,l[4]=p):p=l[4];return p};var e,o=r(d[0]),l=r(d[1]),t=(e=l)&&e.__esModule?e:{default:e},n=r(d[2]);const c={"house.fill":"home","paperplane.fill":"send","chevron.left.forwardslash.chevron.right":"code","chevron.right":"chevron-right"}})(global,__r,__i,__a,module,exports,[1761, 800, 634]);
