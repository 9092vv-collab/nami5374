/* eslint-disable */
// auto-converted from SGU web bundle module 1085
function __r(id){switch(id){case 842: return require('./842');case 882: return require('./882');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";var t=r(d[0]),s=r(d[1]);t.useSettings.subscribe(t=>(0,s.setLanguage)(t.settings.language??"ko")),(0,s.setLanguage)(t.useSettings.getState().settings.language??"ko")})(global,__r,__i,__a,module,exports,[882, 842]);
