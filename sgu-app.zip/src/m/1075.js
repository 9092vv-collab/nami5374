/* eslint-disable */
// Save exported files to a user-chosen folder (Android Storage Access Framework).
const { Directory, File } = require('expo-file-system');
const storeMod = require('./884');
const toast = require('./819');
const CFG = 'settings/download-dir.json';
Object.defineProperty(exports, '__esModule', { value: true });
async function pickDir() {
  const d = await Directory.pickDirectoryAsync();
  if (!d) throw new Error('폴더를 선택하지 않았습니다');
  await storeMod.writeJson(CFG, { uri: d.uri });
  return d;
}
async function targetDir() {
  const cfg = await storeMod.readJson(CFG);
  if (cfg && cfg.uri) { try { const d = new Directory(cfg.uri); if (d.exists !== false) return d; } catch {} }
  return pickDir();
}
function label(uri) {
  try { const s = decodeURIComponent(String(uri)); const m = /tree\/[^:]*:(.*)$/.exec(s); return m ? (m[1] || '내장 저장소') : s; } catch { return String(uri); }
}
async function save(name, bytes, mime) {
  let dir = await targetDir(); let f;
  try { f = await dir.createFile(name, mime || 'application/octet-stream'); }
  catch { dir = await pickDir(); f = await dir.createFile(name, mime || 'application/octet-stream'); }
  await f.write(bytes);
  return label(dir.uri);
}
exports.downloadBytes = async function (name, bytes, mime) {
  const where = await save(name, bytes, mime);
  toast.showToast(`'${name}' 을(를) 다운로드 했습니다`);
  return where;
};
exports.resetDownloadDir = async function () { await storeMod.writeJson(CFG, { uri: '' }); };
exports.downloadFolderLabel = async function () { const c = await storeMod.readJson(CFG); return c && c.uri ? label(c.uri) : ''; };
void File;
