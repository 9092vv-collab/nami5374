/* eslint-disable */
// auto-converted from SGU web bundle module 821
function __r(id){switch(id){case 822: return require('../lib/822');case 823: return require('../lib/823');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.cn=function(...c){return(0,n.twMerge)((0,t.clsx)(c))};var t=r(d[0]),n=r(d[1])})(global,__r,__i,__a,module,exports,[822, 823]);
