/* eslint-disable */
// auto-converted from SGU web bundle module 835
function __r(id){switch(id){case 29: return require('../lib/29');case 324: return require('../lib/324');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,_e,d){"use strict";Object.defineProperty(_e,'__esModule',{value:!0}),Object.defineProperty(_e,"desktop",{enumerable:!0,get:function(){return u}}),Object.defineProperty(_e,"isDesktopApp",{enumerable:!0,get:function(){return o}}),_e.useGridCols=function(){return s()?6:3},_e.useIsWide=s,r(d[0]);var e,n=r(d[1]),t=(e=n)&&e.__esModule?e:{default:e};const u="undefined"!=typeof window?window.sguDesktop??null:null,o=null!=u;function s(){const{width:e}=(0,t.default)();return e>=600}})(global,__r,__i,__a,module,exports,[29, 324]);
