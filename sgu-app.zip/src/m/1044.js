/* eslint-disable */
// Chunked byte readers for zip/charx import (Android).
const { File } = require('expo-file-system');
Object.defineProperty(exports, '__esModule', { value: true });
function bytesReader(n) { return { size: n.length, read: async (t, r) => n.subarray(t, Math.min(n.length, t + r)), close() {} }; }
exports.bytesReader = bytesReader;
exports.openReader = async function (uri) {
  let bytes;
  try { bytes = await new File(uri).bytes(); } catch { bytes = new Uint8Array(await (await fetch(uri)).arrayBuffer()); }
  return bytesReader(bytes);
};
exports.removeCacheFile = function (uri) { try { const f = new File(uri); if (f.exists && String(uri).includes('/cache/')) f.delete(); } catch {} };
