/* eslint-disable */
// HTML preview using react-native-webview (replaces the web iframe).
const React = require('react');
const { View } = require('react-native');
const { WebView } = require('react-native-webview');
Object.defineProperty(exports, '__esModule', { value: true });
exports.HtmlView = function HtmlView({ html, height = 260 }) {
  return React.createElement(View, { style: { height, borderRadius: 10, overflow: 'hidden', borderWidth: 1, borderColor: '#8884' } },
    React.createElement(WebView, { originWhitelist: ['*'], source: { html: String(html || '') }, javaScriptEnabled: false, style: { backgroundColor: '#fff' } }));
};
