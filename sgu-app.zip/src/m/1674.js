/* eslint-disable */
// auto-converted from SGU web bundle module 1674
function __r(id){switch(id){case 964: return require('./964');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,_i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.assetDataUri=async function(n,o){const s=await(0,t.readAssetBytes)(n,o);if(!s)return null;let u="";for(let t=0;t<s.length;t+=32768)u+=String.fromCharCode(...s.subarray(t,t+32768));return`data:${i(s,o.mime)};base64,${btoa(u)}`},e.sniffMime=i;var t=r(d[0]);function i(t,i){const n=(i,...n)=>n.every((n,o)=>t[i+o]===n);return n(0,137,80,78,71)?"image/png":n(0,255,216,255)?"image/jpeg":n(0,71,73,70,56)?"image/gif":n(0,82,73,70,70)&&n(8,87,69,66,80)?"image/webp":n(0,82,73,70,70)&&n(8,87,65,86,69)?"audio/wav":n(4,102,116,121,112)?"video/mp4":n(0,73,68,51)||n(0,255,251)?"audio/mpeg":n(0,79,103,103,83)?"audio/ogg":n(0,26,69,223,163)?"video/webm":i||"application/octet-stream"}})(global,__r,__i,__a,module,exports,[964]);
