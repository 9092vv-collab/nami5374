/* eslint-disable */
// auto-converted from SGU web bundle module 1686
function __r(id){switch(id){default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.remainingSeconds=function(t,n,u){return t<=0||u<=0?null:Math.max(0,Math.ceil(u/1e3*(n-t)/t))},e.formatEta=n,e.gaugeText=function(t,n,u=12){const o=n>0?Math.round(t/n*u):0;return`${"\u25b0".repeat(o)}${"\u25b1".repeat(Math.max(0,u-o))} ${n>0?Math.round(t/n*100):0}%`},e.progressTitle=function(t,u,o){return`\uc5d0\uc14b \uc791\uc5c5(ETA ${n(o)})`};const t=t=>String(t).padStart(2,"0");function n(n){return null==n?"\uacc4\uc0b0 \uc911":`${t(Math.floor(n/60))}\ubd84 ${t(n%60)}\ucd08`}})(global,__r,__i,__a,module,exports,[]);
