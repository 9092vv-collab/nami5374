/* eslint-disable */
// auto-converted from SGU web bundle module 826
function __r(id){switch(id){case 827: return require('./827');case 830: return require('./830');default: throw new Error('missing module '+id);}}
function __i(id){const m=__r(id);return m&&m.__esModule?m.default:m;}
function __a(id){return __r(id);}
(function(g,r,i,a,m,e,d){"use strict";Object.defineProperty(e,'__esModule',{value:!0}),e.useColors=function(s){const u=(0,t.useColorScheme)(),n=s??u??"light";return o.Colors[n]};var o=r(d[0]),t=r(d[1])})(global,__r,__i,__a,module,exports,[827, 830]);
