/* eslint-disable */
// Manus web-preview runtime (iframe postMessage bridge). Not needed on Android.
// The original checked `window.self !== window.top`; in React Native window.self is
// global and window.top is undefined, so it ran window.addEventListener (undefined) and crashed.
Object.defineProperty(exports, '__esModule', { value: true });
exports.subscribeSafeAreaInsets = function () { return function () {}; };
exports.initManusRuntime = function () {};
exports.isRunningInPreviewIframe = function () { return false; };
