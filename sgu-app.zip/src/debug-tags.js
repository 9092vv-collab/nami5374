/* eslint-disable */
// TEMPORARY UI labels so the user can point at things ("849.12 button is too wide").
//  - Every tappable element shows an orange tag "<module>.<n>" (n = nth element created in
//    src/m/<module>.js, numbered at build time by plugins/babel-debug-tags.js).
//  - Every screen shows a dark tag "S<module>" (route files in app/).
// To remove: set ENABLED = false (or delete this file, the babel plugin, and the app/ wrappers).
const React = require('react');
const RN = require('react-native');

const ENABLED = true;

const tagBase = {
  position: 'absolute',
  zIndex: 9999,
  elevation: 50,
  paddingHorizontal: 2,
  borderRadius: 3,
  fontSize: 9,
  lineHeight: 11,
  fontWeight: '700',
  color: '#FFFFFF',
  includeFontPadding: false,
};
const styles = RN.StyleSheet.create({
  item: { ...tagBase, top: 0, left: 0, backgroundColor: 'rgba(217,119,87,0.92)' },
  screen: { ...tagBase, top: 2, right: '40%', fontSize: 10, lineHeight: 13, paddingHorizontal: 4, backgroundColor: 'rgba(20,20,19,0.85)' },
});

function Tag({ text, kind }) {
  return React.createElement(RN.Text, { pointerEvents: 'none', style: kind === 'screen' ? styles.screen : styles.item, allowFontScaling: false }, text);
}

/** Wraps a Pressable-like component so it shows its __dbg tag in its top-left corner. */
function tagPressable(Comp, name) {
  const Tagged = React.forwardRef(function TaggedPressable(props, ref) {
    const { __dbg, children, ...rest } = props;
    if (!ENABLED || !__dbg) return React.createElement(Comp, { ...rest, ref }, children);
    const tag = React.createElement(Tag, { key: '__dbg', text: __dbg });
    const kids = typeof children === 'function'
      ? (state) => [React.createElement(React.Fragment, { key: 'c' }, children(state)), tag]
      : [React.createElement(React.Fragment, { key: 'c' }, children), tag];
    return React.createElement(Comp, { ...rest, ref }, kids);
  });
  Tagged.displayName = name || Comp.displayName || 'Pressable';
  return Tagged;
}

/** Route wrapper: renders the screen plus a "S<module>" tag. */
function withScreenTag(Screen, id) {
  if (!ENABLED) return Screen;
  function TaggedScreen(props) {
    return React.createElement(React.Fragment, null,
      React.createElement(Screen, props),
      React.createElement(Tag, { text: 'S' + id, kind: 'screen' }));
  }
  TaggedScreen.displayName = 'Screen' + id;
  return TaggedScreen;
}

module.exports = { ENABLED, Tag, tagPressable, withScreenTag };
