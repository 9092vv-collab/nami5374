/* eslint-disable */
// Runs before the app: gesture handler must load first on Android.
import 'react-native-gesture-handler';
