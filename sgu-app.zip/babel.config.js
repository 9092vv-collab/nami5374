module.exports = function (api) {
  api.cache(true);
  return {
    presets: [['babel-preset-expo', { jsxImportSource: 'nativewind' }], 'nativewind/babel'],
    // TEMPORARY UI number tags (see src/debug-tags.js)
    plugins: ['./plugins/babel-debug-tags'],
  };
};
