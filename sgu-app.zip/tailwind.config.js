/** @type {import('tailwindcss').Config} */
const v = (n) => `var(--color-${n})`;
module.exports = {
  content: ['./app/**/*.{js,jsx,ts,tsx}', './src/**/*.js'],
  presets: [require('nativewind/preset')],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        primary: v('primary'), background: v('background'), surface: v('surface'),
        foreground: v('foreground'), muted: v('muted'), border: v('border'),
        success: v('success'), warning: v('warning'), error: v('error'),
      },
    },
  },
  plugins: [],
};
