// Instead of silently closing on a crash, SGU shows the error text on a plain native
// screen (separate ":crash" process) with a copy button, so the cause can be read on the phone.
const fs = require('fs');
const path = require('path');
const { withAndroidManifest, withMainApplication, withMainActivity, withDangerousMod } = require('expo/config-plugins');

const PKG = 'space.sgu.fold';

const ACTIVITY = `package ${PKG}

import android.app.Activity
import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.util.Log
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.system.exitProcess

class CrashReportActivity : Activity() {
  companion object {
    private const val FILE = "sgu-crash.txt"

    fun install(app: Application) {
      val prev = Thread.getDefaultUncaughtExceptionHandler()
      Thread.setDefaultUncaughtExceptionHandler { t, e ->
        try {
          val text = buildString {
            append("SGU ").append(BuildConfig.VERSION_NAME)
            append(" / Android ").append(Build.VERSION.RELEASE).append(" / ").append(Build.MODEL).append('\\n')
            append("thread: ").append(t.name).append("\\n\\n")
            append(Log.getStackTraceString(e))
          }
          File(app.filesDir, FILE).writeText(text)
          app.startActivity(Intent(app, CrashReportActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
          Process.killProcess(Process.myPid())
          exitProcess(10)
        } catch (x: Throwable) {
          prev?.uncaughtException(t, e)
        }
      }
    }

    /** Called first thing in MainActivity: if the last run crashed, show the report instead. */
    fun redirectIfPending(a: Activity): Boolean {
      if (!File(a.filesDir, FILE).exists()) return false
      a.startActivity(Intent(a, CrashReportActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
      Process.killProcess(Process.myPid())
      exitProcess(10)
    }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val f = File(filesDir, FILE)
    val report = try { f.readText() } catch (err: Throwable) { "(오류 기록을 읽지 못했어요)" }
    f.delete()

    val dp = resources.displayMetrics.density
    fun px(v: Int) = (v * dp).toInt()
    val root = LinearLayout(this).apply {
      orientation = LinearLayout.VERTICAL
      setBackgroundColor(Color.parseColor("#F5F4ED"))
      setPadding(px(20), px(56), px(20), px(28))
      fitsSystemWindows = true
    }
    root.addView(TextView(this).apply {
      text = "앱이 오류로 멈췄어요"
      textSize = 22f
      setTypeface(typeface, Typeface.BOLD)
      setTextColor(Color.parseColor("#1F1E1D"))
    })
    root.addView(TextView(this).apply {
      text = "아래 '오류 내용 복사'를 눌러 Claude에게 붙여넣어 주세요."
      textSize = 15f
      setTextColor(Color.parseColor("#5E5D59"))
      setPadding(0, px(6), 0, px(14))
    })
    val body = TextView(this).apply {
      text = report
      textSize = 11f
      typeface = Typeface.MONOSPACE
      setTextIsSelectable(true)
      setTextColor(Color.parseColor("#1F1E1D"))
      setBackgroundColor(Color.WHITE)
      setPadding(px(12), px(12), px(12), px(12))
    }
    root.addView(ScrollView(this).apply { addView(body) },
      LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, px(14), 0, 0) }
    row.addView(Button(this).apply {
      text = "오류 내용 복사"
      setOnClickListener {
        (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
          .setPrimaryClip(ClipData.newPlainText("SGU crash", report))
        Toast.makeText(this@CrashReportActivity, "복사했어요", Toast.LENGTH_SHORT).show()
      }
    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    row.addView(Button(this).apply {
      text = "다시 시작"
      setOnClickListener {
        packageManager.getLaunchIntentForPackage(packageName)?.let {
          startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        }
        finish()
        Process.killProcess(Process.myPid())
      }
    }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
    root.addView(row)
    setContentView(root)
  }
}
`;

function insertAfter(src, anchorRe, code, what) {
  if (src.includes(code.trim())) return src;
  const m = src.match(anchorRe);
  if (!m) throw new Error(`[with-crash-screen] anchor not found in ${what}: ${anchorRe}`);
  const at = m.index + m[0].length;
  return src.slice(0, at) + code + src.slice(at);
}

module.exports = function withCrashScreen(config) {
  config = withDangerousMod(config, ['android', async (cfg) => {
    const dir = path.join(cfg.modRequest.platformProjectRoot, 'app/src/main/java', ...PKG.split('.'));
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'CrashReportActivity.kt'), ACTIVITY);
    return cfg;
  }]);
  config = withMainApplication(config, (cfg) => {
    cfg.modResults.contents = insertAfter(cfg.modResults.contents, /super\.onCreate\(\)/,
      '\n    CrashReportActivity.install(this)', 'MainApplication');
    return cfg;
  });
  config = withMainActivity(config, (cfg) => {
    cfg.modResults.contents = insertAfter(cfg.modResults.contents,
      /override fun onCreate\(savedInstanceState: Bundle\?\)\s*\{/,
      '\n    if (CrashReportActivity.redirectIfPending(this)) return', 'MainActivity');
    return cfg;
  });
  config = withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application[0];
    app.activity = app.activity || [];
    const name = '.CrashReportActivity';
    if (!app.activity.some((a) => a.$['android:name'] === name)) {
      app.activity.push({ $: {
        'android:name': name,
        'android:process': ':crash',
        'android:exported': 'false',
        'android:theme': '@android:style/Theme.DeviceDefault.Light.NoActionBar',
      } });
    }
    return cfg;
  });
  return config;
};
