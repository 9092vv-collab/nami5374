// TEMPORARY: numbers every element created in src/m/<module>.js as "<module>.<n>" and passes
// it as a `__dbg` prop (first in the props object, so a caller's tag that is spread through
// wins). Tappable components show it on screen (see src/debug-tags.js). Remove from
// babel.config.js together with src/debug-tags.js when done.
module.exports = function babelDebugTags({ types: t }) {
  const isJsxCallee = (c) => {
    if (t.isSequenceExpression(c)) c = c.expressions[c.expressions.length - 1];
    return t.isMemberExpression(c) && t.isIdentifier(c.property) && ['jsx', 'jsxs'].includes(c.property.name);
  };
  return {
    name: 'sgu-debug-tags',
    visitor: {
      Program(path, state) {
        const file = (state.filename || '').replace(/\\/g, '/');
        const m = file.match(/\/src\/m\/(\d+)\.js$/);
        if (!m) return;
        const mod = m[1];
        let n = 0;
        path.traverse({
          CallExpression(p) {
            const [comp, props] = p.node.arguments;
            if (!comp || !props || !t.isObjectExpression(props) || !isJsxCallee(p.node.callee)) return;
            n += 1;
            props.properties.unshift(t.objectProperty(t.identifier('__dbg'), t.stringLiteral(`${mod}.${n}`)));
          },
        });
      },
    },
  };
};
