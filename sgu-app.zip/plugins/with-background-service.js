// Registers the react-native-background-actions foreground service (dataSync) so long
// character jobs keep running with the screen off.
const { withAndroidManifest } = require('expo/config-plugins');
module.exports = function withBackgroundService(config) {
  return withAndroidManifest(config, (cfg) => {
    const app = cfg.modResults.manifest.application[0];
    app.service = app.service || [];
    const name = 'com.asterinet.react.bgactions.RNBackgroundActionsTask';
    if (!app.service.some((s) => s.$['android:name'] === name)) {
      app.service.push({ $: { 'android:name': name, 'android:exported': 'false', 'android:foregroundServiceType': 'dataSync' } });
    }
    return cfg;
  });
};
