#!/usr/bin/env bash
# Installs every Expo/React Native package at the version that matches this Expo SDK.
set -euo pipefail
npm install --no-audit --no-fund
npx expo install \
  react-native react-dom expo-router expo-constants expo-linking expo-status-bar expo-font expo-asset \
  expo-file-system expo-secure-store expo-notifications expo-intent-launcher expo-sharing \
  expo-document-picker expo-image-picker expo-image-manipulator expo-image expo-clipboard \
  expo-haptics expo-keep-awake expo-build-properties expo-splash-screen expo-system-ui \
  @expo/vector-icons @react-navigation/elements @react-navigation/native \
  react-native-reanimated react-native-worklets react-native-gesture-handler \
  react-native-safe-area-context react-native-screens react-native-svg react-native-webview \
  react-native-css-interop
npx expo install --fix || true
