#!/usr/bin/env bash
# Puts Pretendard GOV (OFL-1.1) font files into assets/fonts.
set -euo pipefail
OUT=assets/fonts; mkdir -p "$OUT"
W="Regular Medium SemiBold Bold ExtraBold"
have(){ for w in $W; do [ -f "$OUT/PretendardGOV-$w.otf" ] || return 1; done; }
have && { echo "fonts already present"; exit 0; }
TMP=$(mktemp -d)
if curl -fsSL -o "$TMP/gov.zip" "https://github.com/orioncactus/pretendard/releases/download/v1.3.9/PretendardGOV-1.3.9.zip"; then
  (cd "$TMP" && unzip -q gov.zip)
fi
if ! find "$TMP" -name 'PretendardGOV-Regular.otf' | grep -q .; then
  (cd "$TMP" && npm pack pretendard-gov@1.3.9 --silent && tar xzf pretendard-gov-*.tgz)
fi
if ! find "$TMP" -name 'PretendardGOV-Regular.otf' | grep -q .; then
  for w in $W; do curl -fsSL -o "$TMP/PretendardGOV-$w.otf" "https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/packages/pretendard-gov/dist/public/static/PretendardGOV-$w.otf" || true; done
fi
for w in $W; do
  f=$(find "$TMP" -name "PretendardGOV-$w.otf" | head -1)
  [ -n "$f" ] || { echo "missing PretendardGOV-$w.otf"; exit 1; }
  cp "$f" "$OUT/"
done
ls -la "$OUT"
